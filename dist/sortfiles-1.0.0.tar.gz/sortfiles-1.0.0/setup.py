from setuptools import setup, find_packages

setup(
    name='sortfile',
    version='0.1.0',
    packages=find_packages(),
    author='Johann',
    install_requires=[
        'argparse',
        'shutil',
        'os',
    ])